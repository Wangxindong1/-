import requests
import xlwt
from bs4 import BeautifulSoup

def getHTMLText(url):
    try:
        r = requests.get(url)
        r.raise_for_status()
        r.encoding = r.apparent_encoding
        return r.text
    except:
        print("error")
        print(url)
        print("error here")
        return ""

def getInfoPhone(url):
    html = getHTMLText(url)
    soup = BeautifulSoup(html,'html.parser')
    item_name_list = []
    item_link_list = []
    item_info = soup.find_all('div', {'id': 'J_goodsList'})
    items = item_info[0].find_all('div', {'class': 'p-name p-name-type-2'})
    for item in items:
        a_element = item.find('a',{'target':'_blank'})
        em = item.find('em',{})
        item_name = em.text.strip()
        item_name_list.append(item_name)
        item_link = a_element.get('href')
        item_link_list.append(item_link)
    
    return item_name_list,item_link_list

def set_style(name, height, bold=False):
    style = xlwt.XFStyle()  # 初始化样式

    font = xlwt.Font()  # 为样式创建字体
    font.name = name  # 'Times New Roman'
    font.bold = bold
    font.color_index = 4
    font.height = height
    style.font = font
    return style


def write_excel(name_list, link_list):
    f = xlwt.Workbook()  # 创建工作簿

    ''''' 
    创建第一个sheet: 
    sheet1 
    '''
    sheet1 = f.add_sheet(u'sheet1', cell_overwrite_ok=True)  # 创建sheet
    row0 = [u'手机型号',u'购买链接']
    first_col = sheet1.col(0)
    second_col = sheet1.col(1)
    first_col.width = 256*80
    second_col.width = 256*40
    style1 = set_style('Times New Roman', 280, True)
    style2 = set_style('Times New Roman', 220)
    #生成第一行
    for i in range(0, len(row0)):
        sheet1.write(0, i, row0[i], style1)
    for i in range(0, len(name_list)):
        sheet1.write(i+1, 0, name_list[i], style2)
    for i in range(0, len(link_list)):
        sheet1.write(i+1, 1, link_list[i], style2)
    f.save('phone_data.xlsx')  # 保存文件

if __name__ == "__main__":
    url1_start ='https://search.jd.com/Search?keyword=%E5%AE%89%E5%8D%93%E6%89%8B%E6%9C%BA&enc=utf-8&qrst=1&rt=1&stop=1&vt=2&wq=%E5%AE%89%E5%8D%93%E6%89%8B%E6%9C%BA&page='
    url1_end ='&s=57&click=0'
    url2_start ='https://search.jd.com/Search?keyword=%E6%99%BA%E8%83%BD%E6%89%8B%E6%9C%BA&enc=utf-8&qrst=1&rt=1&stop=1&vt=2&wq=%E6%99%BA%E8%83%BD%E6%89%8B%E6%9C%BA&page='
    url2_end = '&s=57&click=0'
    url3_start ='https://search.jd.com/Search?keyword=%E8%80%81%E5%B9%B4%E6%89%8B%E6%9C%BA&enc=utf-8&qrst=1&rt=1&stop=1&vt=2&wq=%E8%80%81%E5%B9%B4%E6%89%8B%E6%9C%BA&page='
    url3_end = '&s=60&click=0'
    url4_start ='https://search.jd.com/Search?keyword=%E8%8B%B9%E6%9E%9C%E6%89%8B%E6%9C%BA&enc=utf-8&qrst=1&rt=1&stop=1&vt=2&bs=1&wq=%E8%8B%B9%E6%9E%9C%E6%89%8B%E6%9C%BA&ev=exbrand_Apple%5E&page='
    url4_end = '&s=57&click=0'
    name_temp_list =[]
    link_temp_list =[]
    name_list = []
    link_list = []

    for i in range(100):
        url = url1_start + str(2*i+1) + url1_end
        print(url)
        name_temp_list,link_temp_list = getInfoPhone(url)
        name_list += name_temp_list
        link_list += link_temp_list

    for i in range(100):
        url = url2_start + str(2*i+1) + url2_end
        print(url)
        name_temp_list,link_temp_list = getInfoPhone(url)
        name_list += name_temp_list
        link_list += link_temp_list

    for i in range(100):
        print(url)
        url = url3_start + str(2*i+1) + url3_end
        name_temp_list,link_temp_list = getInfoPhone(url)
        name_list += name_temp_list
        link_list += link_temp_list

    for i in range(50):
        print(url)
        url = url4_start + str(2*i+1) + url4_end
        name_temp_list,link_temp_list = getInfoPhone(url)
        name_list += name_temp_list
        link_list += link_temp_list

    write_excel(name_list, link_list)
    
    
